import 'package:flutter/widgets.dart';

class MyFlutterApp {
  MyFlutterApp._();

  static const _kFontFam = 'MyFlutterApp';
  static const String _kFontPkg = null;

  static const IconData handshake = IconData(0xf2b5, fontFamily: _kFontFam, fontPackage: _kFontPkg);
}
