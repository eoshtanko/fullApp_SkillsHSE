String ANIMATED_SPLASH = '/SplashScreen',
    PROFILE = '/ProfilePage',
    LOGIN_SCREEN = '/MyProfile';