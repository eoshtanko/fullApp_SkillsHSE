
import 'package:demoapp/data/profile.dart';

class CurrentUser{
  static Profile profile;
}